#! /usr/bin/env python

import rospy                               # Import the Python library for ROS
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist


def callback(msg):

    length = 720
                                    # Define a function called 'callback' that receives a parameter
    if msg.ranges[length/2]>1:
        cmd_v.linear.x=0.1
        cmd_v.angular.z=0.0
        cmd_pub.publish(cmd_v)
        if msg.ranges[length-length/4]<0.4:
            cmd_v.linear.x = -0.1
            cmd_v.angular.z = -0.2
            cmd_pub.publish(cmd_v)
        elif msg.ranges[length/4]<0.4:
            cmd_v.linear.x = -0.1
            cmd_v.angular.z=0.2
            cmd_pub.publish(cmd_v)
    elif msg.ranges[length/2]<1:
        cmd_v.linear.x=0.0
        cmd_pub.publish(cmd_v)
        if msg.ranges[length/2]<0.7:
            cmd_v.linear.x=-0.1
            cmd_pub.publish(cmd_v)
        elif msg.ranges[length-length/4]<msg.ranges[length/4]:
            cmd_v.angular.z=-0.3
            cmd_pub.publish(cmd_v)
        else:
            cmd_v.angular.z=0.3
            cmd_pub.publish(cmd_v)


if __name__=='__main__':
    rospy.init_node('topic_node')
    global cmd_v
    cmd_v = Twist()
    cmd_pub = rospy.Publisher('/cmd_vel',Twist, queue_size=1)

    cmd_v.linear.x=0.1
    rate = rospy.Rate(2)

    sub = rospy.Subscriber('/kobuki/laser/scan', LaserScan, callback)

                          # Set a publish rate of 2 Hz                            # Initialize 'count' variable

    while not rospy.is_shutdown():
        cmd_pub.publish(cmd_v)
        rate.sleep()
        rospy.spin()